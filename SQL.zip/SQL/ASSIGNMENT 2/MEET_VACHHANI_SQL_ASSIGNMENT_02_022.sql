
--Assignment 2
--21 Create View to fetch the result of FirstName, LastName, MiddleName, DOB, Chart Number, Sex , Race , Primary Address, Primary Phone, Primary Fax.

CREATE or REPLACE VIEW Patient_view AS
    SELECT pt.Patient_id, pt.FIRST_NAME, pt.LAST_NAME, pt.MIDDLE_NAME, pt.DOB, pt.CHART_NUMBER, pt.SEX, rt.RACE_ID, adt.ADDRESS_TYPE, adt.STREET, adt.CITY, adt.ZIP, adt.STATE, adt.COUNTRY, pht.PHONE_NUM, pht.PHONE_TYPE, ft.FAX_NUM
    FROM Patient as pt LEFT JOIN Sex as st on pt.sex = st.SEX_ID
    		LEFT JOIN race as rt on pt.patient_id = rt.patient_id 
    		LEFT JOIN race_type as rtt on rt.race_type = rtt.race_type_id and pt.patient_id = rt.patient_id
    		LEFT JOIN preference_type as prtt on prtt.preference_type::text = 'Primary'::text
    		LEFT JOIN preference as prt on pt.patient_id = prt.patient_id and prt.preference_type_id = prtt.preference_type_id  
    		LEFT JOIN address as adt on adt.address_id = prt.address_id and pt.patient_id = adt.patient_id 
    		LEFT JOIN phone as pht on pht.phone_id = prt.phone_id 
    		LEFT JOIN fax as ft on ft.fax_id = prt.fax_id; 
    		
--    	Patient NATURAL FULL OUTER JOIN Address on 
--    		NATURAL FULL OUTER JOIN Fax
--    		NATURAL FULL OUTER JOIN Phone
--    		NATURAL FULL OUTER JOIN Race);
--   	ON Address. = true and Phone.PRIM_PHONE = true and Fax.PRIM_FAX = true;

select * from patient_view;
    
--22 Write Query to fetch unique record from the Patient table based on Firstname, LastName, DOB and Sex with number of occurance(count) of same data.
SELECT FIRST_NAME,LAST_NAME,DOB,SEX,COUNT(*) 
FROM Patient 
GROUP BY FIRST_NAME,LAST_NAME,DOB,SEX;

--23 Create Function to stored the data into patient table. Pass all the value in the function parameter and function should return the created new primary key value of the table.
Create function generate_primary_key(FIRST_NAME VARCHAR(20),LAST_NAME VARCHAR(20),MIDDLE_NAME VARCHAR(20),DOB DATE, Sex INT)  
returns int  
language plpgsql  
as  
$$  
Declare 
primary_key integer;
Begin  
  INSERT INTO Patient(FIRST_NAME,LAST_NAME,MIDDLE_NAME,DOB,SEX) values(FIRST_NAME,LAST_NAME,MIDDLE_NAME,DOB,Sex) returning Patient_id into primary_key;
  return primary_key ;  
End;  
$$;  

SELECT generate_primary_key('meet','vachhani','M','2000-01-23',1);

--24 Create Function to get the result of patient’s data by using patientId, lastname, firstname, sex, dob. Need to implement the pagination and sorting(LastName, Firstname, Sex, DOB) in this function.

CREATE OR REPLACE FUNCTION paging(
--	patients_id int DEFAULT null,
	fname varchar DEFAULT null, 
	lname varchar DEFAULT null,
	gender int default null, 
	dateofbirth date default null, 
 	PageNumber INT default 1, 
 	PageSize INT default 10,
 	orderby varchar default 'patient_id'
 )
 RETURNS TABLE ( 
 	FIRST_NAME varchar, 
 	LAST_NAME varchar, 
 	SEX int, 
 	DOB date 
-- 	PageSize integer DEFAULT 10
--  LAST_NAME character, FIRST_NAME character, SEX INT, DOB date
) AS
 $BODY$
 declare
	query1 varchar(2500) := 'select FIRST_NAME,LAST_NAME,SEX,DOB from Patient where 1=1 ';
 	begin
	 	query1 := query1
	 	||	case when $1 is not null then  'and FIRST_NAME = $1' else '' end
	 	||	case when $2 is not null then  'and LAST_NAME = $2' else '' end
	 	||	case when $3 is not null then  'and SEX = $3' else '' end
	 	||	case when $4 is not null then  'and DOB = $4' else '' end
	 	|| ' ORDER BY '|| $7||' ASC LIMIT '|| $6 ||' OFFSET (('||$5||'-1) *'|| $6||')';
	 	raise notice '%' , query1;
		return query execute query1 using fname, lname, gender, dateofbirth, PageNumber, PageSize, orderby;
	END;
$BODY$
LANGUAGE plpgsql;

Select * from paging();
Select * from paging(fname=>null);
Select * from paging(lname=>null);
Select * from paging(gender=>null);
Select * from paging(dateofbirth=>null);
Select * from paging(fname=>'meet');
Select * from paging(lname=>'Shah');
Select * from paging(gender=>1);
Select * from paging(dateofbirth=>'2001-09-19');
Select * from paging(fname=>null,lname=>'Vachhani',gender=>1,dateofbirth=>'2001-09-14');
Select * from paging(fname=>null,lname=>'Vachhani',gender=>1,dateofbirth=>null);

--Select * from paging(sexx=>1);
--Select * from paging(dobb=>'2000-01-23');
Select * from paging(PageNumber=>1,PageSize=>4);
Select * from paging(PageNumber=>2,PageSize=>4);



--25 Write Query to search the patient by patient’s phone no
SELECT
	pt.FIRST_NAME,Pht.PHONE_NUM,add.ADDRESS_ID
FROM
	Patient pt
	INNER JOIN address add ON add.PATIENT_ID = pt.PATIENT_ID
	INNER JOIN phone Pht ON pht.ADDRESS_ID = add.ADDRESS_ID
WHERE Pht.PHONE_NUM = '9491261581';



