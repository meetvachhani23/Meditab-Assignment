﻿using Assignment.Models;
using Microsoft.AspNetCore.Mvc;

namespace Assignment.DataAccessLayer
{
    public interface IAssignmentDAL
    {
        public Task<JsonResult> Get(int id);
        public Task<JsonResult> Get(int id, int pagenumber, int pagesize, int sex_type_id, string fname, string lname, string dob, string orderby);
        public Task<JsonResult> Post(PatientDemographics pd);
        public Task<JsonResult> Put(int id, PatientDemographics pd);
        public Task<JsonResult> Delete(int id);
    }
}
