﻿//namespace WebApplication6
/*{
    public class Helper
    {

        public  object Nulldata(this string? value)
        {
            return value == null || value == "" ? DBNull.Value : value;
        }

        public object Nulldata(this int? value)
        {
            return value == null ? DBNull.Value : value;
        }

        public object Nulldata(this DateTime? value)
        {
            return value == null ? DBNull.Value : value;
        }
    }
}
*/