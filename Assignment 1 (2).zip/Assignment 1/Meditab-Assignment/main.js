function ageCalculator(event) 
{ 
    const ffname = document.getElementById('fname').value;
    const llname = document.getElementById("lname").value;
    const ssex = document.getElementById("Sex").value;
    const dob = document.getElementById("DOB").value;
    
    // var userinput = document.getElementById("DOB").value;  
    // var dob = new Date(userinput);  
    if(ffname!="" && llname!="" && dob!="") 
    {  
        var dob2 = new Date(dob);
        //calculate month difference from current date in time  
        var month_diff = Date.now() - dob2.getTime();  
        
        //convert the calculated difference in date format  
        var age_dt = new Date(month_diff);   
        
        //extract year from date      
        var year = age_dt.getUTCFullYear();  
        
        //now calculate the age of the user  
        var age = Math.abs(year - 1970);  
        
        if(age > 18)
        {   
            const myFormData = new FormData(event.target);
            const formDataObj = {};
            myFormData.forEach((value, key) => (formDataObj[key] = value));
            console.log(formDataObj);
        }
        else
        {
            alert("Fill up the contact details");
        }
    } 
    else 
    {  
        alert("Please Enter All the required Details");
    }  
}  

function resetFunction() 
{
    document.getElementById("s-form").reset();
}
