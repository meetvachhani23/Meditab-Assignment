﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class Patient
    {
        public int Patient_Id { get;}

        public string First_Name { get; set; }

        public string Last_Name { get; set;}

        public int Sex { get; set;}

        public DateTime? DOB { get; set; }

        public bool is_deleted { get;}

    }
}
