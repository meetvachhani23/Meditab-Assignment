﻿using WebApplicatioin4.Models;
using WebApplicatioin4.ServiceLayer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Npgsql;
using System.Data;
using System.Xml.Linq;
using WebApplication4.ServicesLayer;

namespace Assignment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public readonly IWebApplicationSL _IWebApplicationSL;
        private object _WebApplicationSL;

        public PatientController(IConfiguration configuration, IWebApplicationSL webApplicationSL)
        {
            _configuration = configuration;
            _WebApplicationSL = webApplicationSL;
        }



        //Fetch patient detail using id
        [HttpGet("{id}")]
        public async Task<JsonResult> Get(int id)
        {
            try
            {
                return new JsonResult(await _WebApplicationSL.Get(id));
            }
            catch (Exception ex)
            {
                return new JsonResult(ex);
            }
        }

        //Fetch all patient record
        [HttpGet]
        public async Task<JsonResult> Get(int id, int pagenumber, int pagesize, int sex_type_id, string fname, string lname, string dob, string orderby)
        {
            try
            {
                return new JsonResult(await _WebApplicationSL.Get(id, pagenumber, pagesize, sex_type_id, fname, lname, dob, orderby));
            }
            catch (Exception ex)
            {
                return new JsonResult(ex);
            }
        }

        //Insert patient record
        [HttpPost]
        public async Task<JsonResult> Post(Patient pd)
        {
            try
            {
                return new JsonResult(await _WebApplicationSL.Post(pd));
            }
            catch (Exception ex)
            {
                return new JsonResult(ex);
            }
        }

        // Update patient record using id
        [HttpPut("{id}")]
        public async Task<JsonResult> Put(int id, Patient pd)
        {
            try
            {
                return new JsonResult(await _WebApplicationSL.Put(id, pd));
            }
            catch (Exception ex)
            {
                return new JsonResult(ex);
            }
        }

        // Delete patient record using id
        [HttpDelete("{id}")]
        public async Task<JsonResult> Delete(int id)
        {
            try
            {
                return new JsonResult(await _WebApplicationSL.Delete(id));
            }
            catch (Exception ex)
            {
                return new JsonResult(ex);
            }
        }

    }
}
