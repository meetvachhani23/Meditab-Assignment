git add -A

git status

git commit -m "Day3 Commit"

git push -u -f origin main

https://developer.mozilla.org/en-US/docs/Web/JavaScript/Closures

WebIMS Developer Training HTML & CSS Assignment 1

Goal: Create an HTML page with the following layout. It should include the menu on the topbar and the Patient form with sidebar as in the image below. Implement as many controls as you can and emulate the design as closely as possible.

Image resources are present in this drive folder: https://drive.google.com/drive/folders/1u6q2qGSSzfzvS6zhNcLObObpqGkwQmKH?usp=sharing

Instructions for submission:

Separate your HTML and CSS into different files and zip them. Name the zip file in the following format

Upload it on this link https://drive.google.com/drive/folders/1Mqjsc0TmBS8Jepf5UX3IXis9-lxks_0W?usp=sharing

FIRSTNAME_LASTNAME_ASSIGNMENT_01.zip

WebIMS Developer Training Javascript Assignment 2

Goal: In the Patient Form, implement the following functionality

On Click of the reset button, all control values should be cleared On Click of submit button, create an object with the values set in the form and log it via console.log If the Patient is a minor, show an alert with the message “Please add a contact for the Patient as he / she (depending on the gender), is a minor”.

Instructions for submission:

Separate your HTML, CSS and Javascript into different files and zip them. Name the zip file in the following format

FIRSTNAME_LASTNAME_ASSIGNMENT_01.zip

Upload it on this link https://drive.google.com/drive/folders/1Mqjsc0TmBS8Jepf5UX3IXis9-lxks_0W?usp=sharing
