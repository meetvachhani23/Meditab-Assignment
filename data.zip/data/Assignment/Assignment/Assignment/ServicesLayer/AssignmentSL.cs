﻿using Assignment.DataAccessLayer;
using Assignment.Models;
using Microsoft.AspNetCore.Mvc;

namespace Assignment.ServicesLayer
{
    public class AssignmentSL:IAssignmentSL
    {
        public readonly IAssignmentDAL _assignmentDAL;
        public AssignmentSL(IAssignmentDAL assignmentDAL)
        {
            _assignmentDAL = assignmentDAL;
        }

        public async Task<JsonResult> Get(int id)
        {
            return await _assignmentDAL.Get(id);
        }

        public async Task<JsonResult> Get(int id, int pagenumber, int pagesize, int sex_type_id, string fname, string lname, string dob, string orderby)
        {
            return await _assignmentDAL.Get(id, pagenumber, pagesize, sex_type_id, fname, lname, dob, orderby);
        }

        public async Task<JsonResult> Post(PatientDemographics pd)
        {
            return await _assignmentDAL.Post(pd);
        }

        public async Task<JsonResult> Put(int id, PatientDemographics pd)
        {
            return await _assignmentDAL.Put(id, pd);
        }
        public async Task<JsonResult> Delete(int id)
        {
            return await _assignmentDAL.Delete(id);
        }
    }
}
