﻿using WebApplication6.Models;
using WebApplication6.ServiceLayer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Npgsql;
using System.Data;
using System.Xml.Linq;
using WebApplication6.RepositoryLayer;

namespace WebApplication6.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WebApplicationController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public readonly IWebApplicationSL _WebApplicationSL;

        public WebApplicationController(IConfiguration configuration, IWebApplicationSL WebApplicationSL)
        {
            _configuration = configuration;
            _WebApplicationSL = WebApplicationSL;
        }


        /// <summary>
        /// Fetch patient detail using id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("{id}")]
        public async Task<dynamic> Get(int id)
        {
            //try
            // {
            return await _WebApplicationSL.Get(id);
            // }
            // catch (Exception ex)
            // {
            //     return ex;
            // }
        }


        /// <summary>
        /// Insert patient record
        /// </summary>
        /// <param name="pt"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<int> Post(Patient pt)
        {
            //try
            //{
            return await _WebApplicationSL.Post(pt);
            //}
            //catch (Exception ex)
            //{
            //    return new JsonResult(ex);
            // }
        }

        // Update patient record using id
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="pt"></param>
        /// <returns></returns>
        [HttpPut("{id}")]
        public async Task<int> Put(int id, Patient pt)
        {
            //try
            //{
            return await _WebApplicationSL.Put(id, pt);
            //}
            //catch (Exception ex)
            //{
            //    return new JsonResult(ex);
            //}
        }

        // Delete patient record using id
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete("{id}")]
        public async Task<JsonResult> Delete(int id)
        {
            try
            {
                return new JsonResult(await _WebApplicationSL.Delete(id));
            }
            catch (Exception ex)
            {
                return new JsonResult(ex);
            }
        }

        // Get all Patient data in pagination
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="pagenumber"></param>
        /// <param name="pagesize"></param>
        /// <param name="sex_type_id"></param>
        /// <param name="fname"></param>
        /// <param name="lname"></param>
        /// <param name="dob"></param>
        /// <param name="orderby"></param>
        /// <returns></returns>
        [HttpPost("search")]
        public async Task<JsonResult> Get(RequestPatientData rpd)
        {
            try
            {
                return new JsonResult(await _WebApplicationSL.Get(rpd));
            }
            catch (Exception ex)
            {
                return new JsonResult(ex);
            }
        }

    }
}


 
