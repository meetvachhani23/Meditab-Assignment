﻿using Assignment.Models;
using Assignment.ServicesLayer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Npgsql;
using System.Data;
using System.Xml.Linq;

namespace Assignment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientDemographicsController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public readonly IAssignmentSL _assignmentSL;

        public PatientDemographicsController(IConfiguration configuration, IAssignmentSL assignmentSL)
        {
            _configuration = configuration;
            _assignmentSL = assignmentSL;
        }



        //Fetch patient detail using id
        [HttpGet("{id}")]
        public async Task<JsonResult> Get(int id)
        {
            try {               
                return new JsonResult(await _assignmentSL.Get(id));
            }
            catch(Exception ex) {
                return new JsonResult(ex);
            }
        }

        //Fetch all patient record
        [HttpGet]
        public async Task<JsonResult> Get(int id, int pagenumber, int pagesize, int sex_type_id, string fname, string lname, string dob, string orderby)
        {
            try
            {
                return new JsonResult(await _assignmentSL.Get(id, pagenumber, pagesize, sex_type_id, fname, lname, dob, orderby));
            }
            catch (Exception ex)
            {
                return new JsonResult(ex);
            }
        }

        //Insert patient record
        [HttpPost]
        public async Task<JsonResult> Post(PatientDemographics pd)
        {
            try
            {
                return new JsonResult(await _assignmentSL.Post(pd));
            }
            catch (Exception ex)
            {
                return new JsonResult(ex);
            }
        }

        // Update patient record using id
        [HttpPut("{id}")]
        public async Task<JsonResult> Put(int id, PatientDemographics pd)
        {
            try
            {
                return new JsonResult(await _assignmentSL.Put(id, pd));
            }
            catch (Exception ex)
            {
                return new JsonResult(ex);
            }
        }

        // Delete patient record using id
        [HttpDelete("{id}")]
        public async Task<JsonResult> Delete(int id)
        {
            try
            {
                return new JsonResult(await _assignmentSL.Delete(id));
            }
            catch (Exception ex)
            {
                return new JsonResult(ex);
            }
        }


        /*
                //Fetch patient detail using id
                [HttpGet("{id}")]
                public JsonResult Get(int id)
                {
                    string query = @"
                        select * from get_patient_by_id(@id)
                    ";

                    DataTable table = new DataTable();
                    string sqlDataSource = _configuration.GetConnectionString("DBcon");
                    NpgsqlDataReader myReader;
                    using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
                    {
                        myCon.Open();
                        using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                        {
                            myCommand.Parameters.AddWithValue("id", id);
                            myReader = myCommand.ExecuteReader();
                            table.Load(myReader);

                            myReader.Close();
                            myCon.Close();
                        }
                    }
                    return new JsonResult(table);
                }*/


        /*       //Fetch all patient record
               [HttpGet]
           public JsonResult Get(int id, int pagenumber, int pagesize, int sex_type_id, string fname, string lname, string dob, string orderby)
           {
               string query = $"select * from get_patient_info(_patient_id=>{id}, _fname=>'{fname}', _lname=>'{lname}', _dob=>'{dob}', _sex_type_id=>{sex_type_id}, _pagenumber=>{pagenumber}, _pagesize=>{pagesize}, _orderby=>'{orderby}')";

               System.Console.WriteLine("\n\n\n\n",query+ "\n\n\n\n");

               DataTable table = new DataTable();
               string sqlDataSource = _configuration.GetConnectionString("DBcon");
               NpgsqlDataReader myReader;
               using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
               {
                   myCon.Open();
                   using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                   {
                       *//*myCommand.Parameters.AddWithValue("id", id);
                       myCommand.Parameters.AddWithValue("fname", fname);
                       myCommand.Parameters.AddWithValue("lname", lname);
                       myCommand.Parameters.AddWithValue("dob", dob);
                       myCommand.Parameters.AddWithValue("sex_type_id", sex_type_id);
                       myCommand.Parameters.AddWithValue("pagenumber", pagenumber);
                       myCommand.Parameters.AddWithValue("pagesize", pagesize);
                       myCommand.Parameters.AddWithValue("orderby", orderby);*//*

                       myReader = myCommand.ExecuteReader();
                       table.Load(myReader);

                       myReader.Close();
                       myCon.Close();
                   }
               }
               return new JsonResult(table);
           }*/



        /*
                    //Insert patient record
                    [HttpPost]
                public JsonResult Post(PatientDemographics pd)
                {
                    string query = @"
                        select insert_patient_info(@fname, @mname, @lname, @dob::date, @sex_type_id)
                    ";

                    DataTable table = new DataTable();
                    string sqlDataSource = _configuration.GetConnectionString("DBcon");
                    NpgsqlDataReader myReader;
                    using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
                    {
                        myCon.Open();
                        using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                        {
                            //Values to be inserted in patient record
                            myCommand.Parameters.AddWithValue("fname", pd.FirstName);
                            myCommand.Parameters.AddWithValue("mname", pd.MiddleName);
                            myCommand.Parameters.AddWithValue("lname", pd.LastName);
                            myCommand.Parameters.AddWithValue("dob", pd.Dob);
                            myCommand.Parameters.AddWithValue("sex_type_id", pd.SexTypeId);

                            myReader = myCommand.ExecuteReader();
                            table.Load(myReader);

                            myReader.Close();
                            myCon.Close();
                        }
                    }
                    return new JsonResult(table);
                }*/


        // Update patient record using id
        /*[HttpPut("{id}")]
         public JsonResult Put(int id, PatientDemographics pd)
         {
             string query = @" 
                  select update_patient_info(@id, @fname, @mname, @lname, @dob::date, @sex_type_id)
             ";

             string sqlDataSource = _configuration.GetConnectionString("DBcon");
             using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
             {
                 myCon.Open();
                 using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                 {
                     myCommand.Parameters.AddWithValue("id", id);
                     myCommand.Parameters.AddWithValue("fname", pd.FirstName);
                     myCommand.Parameters.AddWithValue("mname", pd.MiddleName);
                     myCommand.Parameters.AddWithValue("lname", pd.LastName);
                     myCommand.Parameters.AddWithValue("dob", pd.Dob);
                     myCommand.Parameters.AddWithValue("sex_type_id", pd.SexTypeId);
                     myCommand.ExecuteReader();

                     myCon.Close();
                 }
             }
             return new JsonResult("Data Updated Successfully!");
         }*/

        // Delete patient record using id
       /* [HttpDelete("{id}")]
        public JsonResult Delete(int id)
        {
            string query = @"
                select delete_patient_info(@id)
            ";

            string sqlDataSource = _configuration.GetConnectionString("DBcon");
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("id", id);
                    myCommand.ExecuteReader();

                    myCon.Close();
                }
            }
            return new JsonResult("Deleted Sccessfully!");
        }*/
    }
}
