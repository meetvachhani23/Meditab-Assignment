﻿using WebApplication6.Models;
using Microsoft.AspNetCore.Mvc;
using Npgsql;
using System.Data;

namespace WebApplication6.RepositoryLayer
{
    public class WebApplicationRL : IWebApplicationRL
    {
        private readonly IConfiguration _configuration;
        private string sqlDataSource;
        public WebApplicationRL(IConfiguration configuration)
        {
            _configuration = configuration;
            sqlDataSource = _configuration.GetConnectionString("DBcon");
        }

        public Task<JsonResult> Get(int id)
        {
            DataTable table = new DataTable();
            try
            {
                string query = @"
                    select * from patientget(@id)
                ";

                NpgsqlDataReader myReader;
                using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
                {
                    myCon.Open();
                    using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                    {
                        myCommand.Parameters.AddWithValue("id", id);
                        myReader = myCommand.ExecuteReader();
                        table.Load(myReader);

                        myReader.Close();
                        myCon.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                return Task.FromResult(new JsonResult(ex));
            }
            return Task.FromResult(new JsonResult(table));
        }

       
        public Task<JsonResult> Post(Patient pd)
        {
            string query = @"
                select patientcreate(@fname, @mname, @lname, @dob::date, @sex_type_id)
            ";

            DataTable table = new DataTable();
            NpgsqlDataReader myReader;
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {
                    //Values to be inserted in patient record
                    myCommand.Parameters.AddWithValue("fname", pd.First_Name);
                    myCommand.Parameters.AddWithValue("mname", pd.Middle_Name);
                    myCommand.Parameters.AddWithValue("lname", pd.Last_Name);
                    myCommand.Parameters.AddWithValue("dob", pd.DOB);
                    myCommand.Parameters.AddWithValue("sex_type_id", pd.SEX);

                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();
                }
            }
            return Task.FromResult(new JsonResult(table));
        }

        public Task<JsonResult> Put(int id, Patient pd)
        {
            string query = @" 
                 select patientupdate(@id, @fname, @mname, @lname, @dob::date, @sex_type_id)
            ";

            string sqlDataSource = _configuration.GetConnectionString("DBcon");
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("id", id);
                    myCommand.Parameters.AddWithValue("fname", pd.First_Name);
                    myCommand.Parameters.AddWithValue("mname", pd.Middle_Name);
                    myCommand.Parameters.AddWithValue("lname", pd.Last_Name);
                    myCommand.Parameters.AddWithValue("dob", pd.DOB);
                    myCommand.Parameters.AddWithValue("sex_type_id", pd.SEX);
                    myCommand.ExecuteReader();

                    myCon.Close();
                }
            }
            return Task.FromResult( new JsonResult("Data Updated Successfully!"));
        }

        public  Task<JsonResult> Delete(int id)
        {
            string query = @"
                select patientdelete(@id)
            ";

            string sqlDataSource = _configuration.GetConnectionString("DBcon");
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("id", id);
                    myCommand.ExecuteReader();

                    myCon.Close();
                }
            }
            return Task.FromResult(new JsonResult("Deleted Sccessfully!"));
        }
    }
}


/*
 *  public async Task<JsonResult> Get(int id, int pagenumber, int pagesize, int sex_type_id, string fname, string lname, string dob, string orderby)
        {
            string query = $"select * from get_patient_info(_patient_id=>{id}, _fname=>'{fname}', _lname=>'{lname}', _dob=>'{dob}', _sex_type_id=>{sex_type_id}, _pagenumber=>{pagenumber}, _pagesize=>{pagesize}, _orderby=>'{orderby}')";

            System.Console.WriteLine("\n\n\n\n", query + "\n\n\n\n");

            DataTable table = new DataTable();
            NpgsqlDataReader myReader;
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {


                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult(table);
        }
*/