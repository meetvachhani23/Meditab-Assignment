﻿using WebApplication6.Models;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication6.RepositoryLayer
{
    public interface IWebApplicationRL
    {
        //Fetch patient detail using id
        public Task<dynamic> Get(int id);

        //Insert patient record
        public Task<int> Post(Patient pt);

        // Update patient record using id
        public Task<int> Put(int id, Patient pt);
        
        // Delete patient record using id
        public Task<JsonResult> Delete(int id);

        // Get all Patient data in pagination
        public Task<JsonResult> Get(RequestPatientData rpd);
    }
}

 