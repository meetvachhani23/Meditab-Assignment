﻿using WebApplication4.Models;
using Microsoft.AspNetCore.Mvc;
using Npgsql;
using System.Data;
namespace WebApplication4.RepositoryLayer
{
    public class WebApplicationRL : IWebApplicationnRL
    {
        private readonly IConfiguration _configuration;
        private string sqlDataSource;
        public WebApplicationRL(IConfiguration configuration)
        {
            _configuration = configuration;
            sqlDataSource = _configuration.GetConnectionString("DBcon");
        }

        public async Task<JsonResult> Get(int id)
        {
            DataTable table = new DataTable();
            try
            {
                string query = @"
                    select * from get_patient_by_id(@id)
                ";

                NpgsqlDataReader myReader;
                using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
                {
                    myCon.Open();
                    using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                    {
                        myCommand.Parameters.AddWithValue("id", id);
                        myReader = myCommand.ExecuteReader();
                        table.Load(myReader);

                        myReader.Close();
                        myCon.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                //return new JsonResult(ex);
            }
            return new JsonResult(table);
        }

        public async Task<JsonResult> Get(int id, int pagenumber, int pagesize, int sex_type_id, string fname, string lname, string dob, string orderby)
        {
            string query = $"select * from get_patient_info(_patient_id=>{id}, _fname=>'{fname}', _lname=>'{lname}', _dob=>'{dob}', _sex_type_id=>{sex_type_id}, _pagenumber=>{pagenumber}, _pagesize=>{pagesize}, _orderby=>'{orderby}')";

            System.Console.WriteLine("\n\n\n\n", query + "\n\n\n\n");

            DataTable table = new DataTable();
            NpgsqlDataReader myReader;
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {


                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult(table);
        }

        public async Task<JsonResult> Post(Patient pd)
        {
            string query = @"
                select insert_patient_info(@fname, @mname, @lname, @dob::date, @sex_type_id)
            ";

            DataTable table = new DataTable();
            NpgsqlDataReader myReader;
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {
                    //Values to be inserted in patient record
                    myCommand.Parameters.AddWithValue("fname", pd.First_Name);
                    myCommand.Parameters.AddWithValue("mname", pd.Middle_Name);
                    myCommand.Parameters.AddWithValue("lname", pd.Last_Name);
                    myCommand.Parameters.AddWithValue("dob", pd.DOB);
                    myCommand.Parameters.AddWithValue("sex_type_id", pd.SEX);

                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();
                }
            }
            return new JsonResult(table);
        }

        public async Task<JsonResult> Put(int id, Patient pd)
        {
            string query = @" 
                 select update_patient_info(@id, @fname, @mname, @lname, @dob::date, @sex_type_id)
            ";

            string sqlDataSource = _configuration.GetConnectionString("DBcon");
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("id", id);
                    myCommand.Parameters.AddWithValue("fname", pd.First_Name);
                    myCommand.Parameters.AddWithValue("mname", pd.Middle_Name);
                    myCommand.Parameters.AddWithValue("lname", pd.Last_Name);
                    myCommand.Parameters.AddWithValue("dob", pd.DOB);
                    myCommand.Parameters.AddWithValue("sex_type_id", pd.SEX);
                    myCommand.ExecuteReader();

                    myCon.Close();
                }
            }
            return new JsonResult("Data Updated Successfully!");
        }

        public async Task<JsonResult> Delete(int id)
        {
            string query = @"
                select delete_patient_info(@id)
            ";

            string sqlDataSource = _configuration.GetConnectionString("DBcon");
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("id", id);
                    myCommand.ExecuteReader();

                    myCon.Close();
                }
            }
            return new JsonResult("Deleted Sccessfully!");
        }
    }
}
