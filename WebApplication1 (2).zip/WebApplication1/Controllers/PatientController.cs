﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualBasic;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public PatientController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        public JsonResult Get()
        {
            string query = @"
                select Patient_Id as ""Patient_Id"",
                        First_Name as ""First_Name"",
                        Last_Name as ""Last_Name"",
                        Sex as ""Sex"",
                        DOB as ""DOB""
                from Patient 
                where is_deleted =false
            ";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmployeeAppCon");
            NpgsqlDataReader myReader;
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();

                }
            }

            return new JsonResult(table);
        }


        

        [HttpPost]
        public JsonResult Post(Patient pt)
        {
            string query = @"
                insert into Patient(First_Name,Last_Name,Sex,DOB)
                values (@First_Name,@Last_Name,@Sex,@DOB)
                where is_deleted =false
            ";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmployeeAppCon");
            NpgsqlDataReader myReader;
            
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@First_Name", pt.First_Name);
                    myCommand.Parameters.AddWithValue("@Last_Name", pt.Last_Name);
                    myCommand.Parameters.AddWithValue("@Sex", pt.Sex);
                    myCommand.Parameters.AddWithValue("DOB", pt.DOB);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();

                }
            }

            return new JsonResult("Added Succesfully");
        }

        [HttpPut]
        public JsonResult Put(Patient pt)
        {
            string query = @"
                update Patient
                set First_Name = @First_Name
                where Patient_Id=@Patient_Id and is_deleted =false
            ";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmployeeAppCon");
            NpgsqlDataReader myReader;
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@Patient_Id", pt.Patient_Id);
                    myCommand.Parameters.AddWithValue("@First_Name", pt.First_Name);
                    myCommand.Parameters.AddWithValue("@Last_Name", pt.Last_Name);
                    myCommand.Parameters.AddWithValue("@Sex", pt.Sex);
                    myCommand.Parameters.AddWithValue("DOB", pt.DOB);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();

                }
            }

            return new JsonResult("Updated Successfully");
        }

        [HttpDelete("{id}")]
        public JsonResult Delete(int id)
        {
            string query = @"
                    update Patient set is_deleted = true where Patient_Id = @id
            ";
            /*            
             *                            alter table Patient add column is_deleted bool default false 

            */
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmployeeAppCon");
            NpgsqlDataReader myReader;
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("@id", id);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();

                }
            }

            return new JsonResult("Deleted Successfully");
        }

        /*[HttpGet("{id}")]
        public JsonResult Get(int id)
        {
            string query = @"
                select Patient_Id as ""Patient_Id"",
                        First_Name as ""First_Name"",
                        Last_Name as ""Last_Name"",
                        Sex as ""Sex"",
                        DOB as ""DOB"" 
                from Patient
                where Patient_Id=@Patient_Id
            ";

            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmployeeAppCon");
            NpgsqlDataReader myReader;
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {
                    myCommand.Parameters.AddWithValue("Patient_Id", id);
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();

                }
            }

            return new JsonResult(table);
        }*/

    }
}
