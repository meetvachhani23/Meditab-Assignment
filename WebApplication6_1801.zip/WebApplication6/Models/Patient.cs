﻿namespace WebApplication6.Models
{
    public class PatientList
    {
        public List<Patient>? PatientdataList{ get; set; }
    }

    public class Patient
    {
        public string? First_Name { get; set; } = null;
        public string? Middle_Name { get; set; } = null;
        public string? Last_Name { get; set; } = null;
        public DateTime? DOB { get; set; } = null;
        public int? SEX { get; set; } = null;
        public string? Chart_Number { get; set; } = null;
        private bool is_deleted { get;}
        private DateTime? CreatedOn { get;}
        private DateTime? ModifiedOn { get; }
    }

    public class RequestPatientData
    {
        public int? Patient_id { get; set; } = null;
        public string? First_Name { get; set; } = null;
        public string? Middle_Name { get; set; } = null;
        public string? Last_Name { get; set; } = null;
        public DateTime? DOB { get; set; } = null;
        public int? SEX { get; set; } = null;
        public int? PageNumber { get; set; } = null;
        public int? PageSize { get; set; } = null;
        public string? OrderBy { get; set; } = null;

    }
}
