﻿namespace WebApplication6.Models
{
    public class Patient
    {
        public int Patient_id { get; }
        public string First_Name { get; set; } = string.Empty;
        public string Middle_Name { get; set; } = string.Empty;
        public string Last_Name { get; set; } = string.Empty;
        public DateTime DOB { get; set; }
        public int SEX { get; set; }
        // public string CHART_NUMBER { get; }
        private bool is_deleted { get;}
        private DateTime? CreatedOn { get;}
        private DateTime? ModifiedOn { get; }
    }
}
