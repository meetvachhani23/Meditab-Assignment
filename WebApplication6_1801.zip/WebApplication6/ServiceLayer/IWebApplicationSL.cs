﻿using WebApplication6.Models;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication6.ServiceLayer
{
    public interface IWebApplicationSL
    {
        public Task<dynamic> Get(int id);
       
        public Task<int> Post(Patient pd);
        public Task<int> Put(int id, Patient pd);
        public Task<JsonResult> Delete(int id);

        public Task<JsonResult> Get(RequestPatientData rpd);
    }
}


 
 