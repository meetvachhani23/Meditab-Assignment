﻿using WebApplication6.Models;
using Microsoft.AspNetCore.Mvc;
using Npgsql;
using System.Data;
using System.Transactions;

namespace WebApplication6.RepositoryLayer
{
    public class WebApplicationRL : IWebApplicationRL
    {
        private readonly IConfiguration _configuration;
        private string sqlDataSource;


        //private Helper _helper;

        public WebApplicationRL(IConfiguration configuration)
        {
            _configuration = configuration;
            sqlDataSource = _configuration.GetConnectionString("DBcon");
        }

        //public WebApplicationRL(Helper helper)
        //{
        //    _helper = helper;
        //}

         public object Nulldata(string? value)
         {
             return value == null || value == "" ? DBNull.Value : value;
         }

        public object Nulldata(int? value)
        {
            return value == null ? DBNull.Value : value;
        }

        public object Nulldata(DateTime? value)
        {
            return value == null ? DBNull.Value : value;
        }

        static object Agevalidation(DateTime Dob)
        {
            DateTime Now = DateTime.Now;
            int Years = new DateTime(DateTime.Now.Subtract(Dob).Ticks).Year - 1;
            DateTime PastYearDate = Dob.AddYears(Years);
            if(Years>18)
            {
                Console.WriteLine("Above AGE:");
                return Dob;
            }
            else
            {
                Console.WriteLine("Under AGE:");
                return Dob;
            }
        }

        //Fetch patient detail using id
        public async Task<dynamic> Get(int id)
        {
            PatientList pl = new PatientList
            {
                PatientdataList = new List<Patient>()
            };

            DataTable table = new();
            try
            {
                string query = @"
                    select * from patientget(@id)
                ";

                NpgsqlDataReader myReader;
                using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
                {
                    
                    myCon.Open();
                    using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                    {
                        myCommand.Parameters.AddWithValue("id", id);
                        myReader = myCommand.ExecuteReader();
                        table.Load(myReader);

                        if (table.Rows.Count != 0)
                        {
                        DataRow dr = table.Rows[0];
                            pl.PatientdataList.Add(new Patient
                            {
                                First_Name = dr["fname"].ToString(),
                                Middle_Name = dr["mname"].ToString(),
                                Last_Name = dr["lname"].ToString(),
                                DOB = DateTime.Parse(dr["dob"].ToString()),
                                SEX = (int)dr["sex_type_id"],
                                Chart_Number = dr["chart_no"].ToString(),
                            });
                        }
                        else
                        {
                            return await Task.FromResult(-1);
                        }
                       
                        //for (int i = 0; i < table.Rows.Count; i++) 
                        //{ 
                        //}

                        myReader.Close();
                        myCon.Close();
                    }

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return await Task.FromResult(pl);
        }

        //Insert patient record
        public Task<int> Post(Patient pt)
        {
            string query = @"
                select patientcreate(@fname, @mname, @lname, @dob::date, @sex_type_id)
            ";

            int id=0;
            using (TransactionScope transactionScope = new TransactionScope())
            {
                try
                {
                    NpgsqlDataReader myReader;
                    using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
                    {
                        myCon.Open();
                        using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                        {
                            //Values to be inserted in patient record
                            myCommand.Parameters.AddWithValue("fname", Nulldata(pt.First_Name));
                            myCommand.Parameters.AddWithValue("mname", Nulldata(pt.Middle_Name));
                            myCommand.Parameters.AddWithValue("lname", Nulldata(pt.Last_Name));
                            myCommand.Parameters.AddWithValue("dob", Agevalidation((DateTime)Nulldata(pt.DOB)));
                            myCommand.Parameters.AddWithValue("sex_type_id", Nulldata(pt.SEX));

                            myReader = myCommand.ExecuteReader();
                            myReader.Read();

                            id = (int)myReader[0];

                            myReader.Close();
                            transactionScope.Complete();

                        }
                    }
                }
                catch (TransactionException ex)
                {
                    transactionScope.Dispose();
                    Console.WriteLine(ex.Message);
                }
            }

        return Task.FromResult(id);
        }

        // Update patient record using id
        public Task<int> Put(int id, Patient pt)
        {
            string query = @" 
                 select patientupdate(@id, @fname, @mname, @lname, @dob::date, @sex_type_id)
            ";

            int ids=0;
            using (TransactionScope transactionScope = new TransactionScope())
            {
                try
                {
                    NpgsqlDataReader myReader;
                    string sqlDataSource = _configuration.GetConnectionString("DBcon");
                    using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
                    {
                        myCon.Open();
                        using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                        {
                            Console.WriteLine("ERRORR");
                            myCommand.Parameters.AddWithValue("id", Nulldata(id));
                            myCommand.Parameters.AddWithValue("fname", Nulldata(pt.First_Name));
                            myCommand.Parameters.AddWithValue("mname", Nulldata(pt.Middle_Name));
                            myCommand.Parameters.AddWithValue("lname", Nulldata(pt.Last_Name));
                            //Type tp = Agevalidation((DateTime)Nulldata(pt.DOB)).GetType();
                            //if (tp.Equals(typeof(DateTime)))
                            //{
                            myCommand.Parameters.AddWithValue("dob", Agevalidation((DateTime)Nulldata(pt.DOB)));
                            //}
                            //else
                            //{
                                //Response.Write("<script language='javascript'>alert('You pressed Me!');</script>");

                            //}
                            myCommand.Parameters.AddWithValue("sex_type_id", Nulldata(pt.SEX));
                    
                            myReader = myCommand.ExecuteReader();
                            myReader.Read();
                            ids = (int)myReader[0];

                            myReader.Close();
                            transactionScope.Complete();
                        }
                    }
                }
                catch (TransactionException ex)
                {
                    transactionScope.Dispose();
                    Console.WriteLine(ex.Message);
                    Console.WriteLine("ERRORR_ERROR");
                }
            }

            return Task.FromResult(ids);
        }

        // Delete patient record using id
        public Task<JsonResult> Delete(int id)
        {
            string query = @"
                select patientdelete(@id)
            ";
            using (TransactionScope transactionScope = new TransactionScope())
            {
                try
                {
                    string sqlDataSource = _configuration.GetConnectionString("DBcon");
                    using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
                    {
                        myCon.Open();
                        using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                        {
                            myCommand.Parameters.AddWithValue("id", id);
                            myCommand.ExecuteReader();

                            transactionScope.Complete();
                        }
                    }
                }
                catch (TransactionException ex)
                {
                transactionScope.Dispose();
                Console.WriteLine(ex.Message);
                }
            }
            return Task.FromResult(new JsonResult("Deleted Sccessfully!"));
        }

        // Get all Patient data in pagination
        public Task<JsonResult> Get(RequestPatientData rpd)
        {
            //Helper helper= new Helper();

            string query = @"
                   select * from get_patient_info(patient_id=>@id, fname=>@fname, lname=>@lname, dob=>@dob, sex_type_id=>@sex_type_id,
                   pagenumber=>@pagenumber, pagesize=>@pagesize, orderby=>@orderby)";

            System.Console.WriteLine("\n\n\n\n", query + "\n\n\n\n");

            DataTable table = new DataTable();
            NpgsqlDataReader myReader;
            using (NpgsqlConnection myCon = new NpgsqlConnection(sqlDataSource))
            {
                myCon.Open();
                using (NpgsqlCommand myCommand = new NpgsqlCommand(query, myCon))
                {


                    myCommand.Parameters.AddWithValue("id", Nulldata(rpd.Patient_id));
                    myCommand.Parameters.AddWithValue("fname", Nulldata(rpd.First_Name));
                    myCommand.Parameters.AddWithValue("mname", Nulldata(rpd.Middle_Name));
                    myCommand.Parameters.AddWithValue("lname", Nulldata(rpd.Last_Name));
                    myCommand.Parameters.AddWithValue("dob", Nulldata(rpd.DOB));
                    myCommand.Parameters.AddWithValue("sex_type_id", Nulldata(rpd.SEX));
                    myCommand.Parameters.AddWithValue("pagenumber", Nulldata(rpd.PageNumber));
                    myCommand.Parameters.AddWithValue("pagesize", Nulldata(rpd.PageSize));
                    myCommand.Parameters.AddWithValue("orderby", Nulldata(rpd.OrderBy));
                    myReader = myCommand.ExecuteReader();
                    table.Load(myReader);

                    myReader.Close();
                    myCon.Close();
                }
            }
            return Task.FromResult(new JsonResult(table));
        }
    }    
}

