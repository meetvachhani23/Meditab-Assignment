function addAddressField() {
    // alert('hi');
    addressHTML = `									<div class="address w-100">
    <fieldset>
        <legend>
            <div>
                <select name="addressType" id="">
                    <option value="Home">Home</option>
                    <option value="Work">Work</option>
                    <option value="Other">Other</option>
                </select>
            </div>
        </legend>
        <div>
            <div class="flex">
                <div style="width: 98%;">
                    Address
                </div>
                <div style="width: 2%;">
                    <i class="fa-solid fa-trash-can def-color"
                        onclick="removeAddressField(this)"></i>
                </div>
            </div>
            <div>
                Street
                <div class="flex" style="margin-right: 50%;">
                    <input type="text" name="street">
                </div>
            </div>
            <div class="flex" style="column-gap: 2%;">
                <div style="width: 24%;">
                    Zip
                    <input type="text" name="zip" id="">
                </div>
                <div style="width: 24%;">
                    City
                    <input type="text" name="city" id="">
                </div>
                <div style="width: 24%;">
                    State
                    <input type="text" name="state" id="">
                </div>
                <div style="width: 24%;">
                    Country
                    <select name="country" id="">
                        <option value="IN">IN</option>
                        <option value="US">US</option>
                    </select>
                </div>
                <div style="width: 4%;">
                    <i class="fa-solid fa-trash-can def-color"></i>
                </div>
            </div>
        </div>
        <div>
            <div>
                <div>
                    Phone <i class="fa-solid fa-circle-plus def-color"></i>
                </div>
                <div class="flex" style="column-gap: 2%;">
                    <div style="width: 20%;">
                        Type
                    </div>
                    <div style="width: 20%;">
                        Code
                    </div>
                    <div style="width: 20%;">
                        Number
                    </div>
                    <div style="width: 20%;">
                        Ext.
                    </div>
                </div>
                <hr>
                <div class="flex" style="column-gap: 2%;">
                    <div style="width: 20%;">
                        <select name="phonetype" id="">
                            <option value="Cell">Cell</option>
                            <option value="Landline">Landline</option>
                        </select>
                    </div>
                    <div style="width: 20%;">
                        <select name="countrtycode" id="">
                            <option value="+91">+91 India</option>
                            <option value="+1">+1 United States</option>
                        </select>
                    </div>
                    <div style="width: 20%;">
                        <input type="text" name="phoneNumber" placeholder="Number"
                            value="1">
                    </div>
                    <div style="width: 20%;">
                    </div>
                </div>
            </div>
            <div>
                <div>
                    Fax <i class="fa-solid fa-circle-plus def-color"></i>
                </div>
                <div class="flex" style="column-gap: 2%;">
                    <div style="width: 20%;">
                        Code
                    </div>
                    <div style="width: 20%;">
                        Number
                    </div>
                </div>
                <hr>
                <div class="flex" style="column-gap: 2%;">
                    <div style="width: 20%;">
                        <input type="text" placeholder="Code" name="faxcode">
                    </div>
                    <div style="width: 20%;">
                        <input type="text" placeholder="Number" name="faxnumber">
                    </div>
                    <div style="width: 2%;">
                        <i class="fa-solid fa-trash-can def-color"></i>
                    </div>
                </div>
            </div>
            <div class="emailSection">
                <div>
                    Email <i class="fa-solid fa-circle-plus def-color"
                        onclick="addEmailField(this)"></i>
                </div>
                <div class="multiEmail" id="multiEmail">
                    <div class="flex singleEmail" name="singleEmail"
                        style="column-gap: 2%;">
                        <div style="width: 50%;">
                            <input type="email" name="email">
                        </div>
                        <div style="width: 2%;">
                            <i class="fa-solid fa-trash-can def-color"
                                onclick="removeEmailField(this)"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <div>
                    Website <i class="fa-solid fa-circle-plus def-color"></i>
                </div>
                <div class="flex" style="column-gap: 2%;">
                    <div style="width: 50%;">
                        <input type="text" name="website">
                    </div>
                    <div style="width: 2%;">
                        <i class="fa-solid fa-trash-can def-color"></i>
                    </div>
                </div>
            </div>
        </div>
    </fieldset>
</div>
`
    document.getElementById("multiadress").innerHTML += addressHTML
}

function removeAddressField(btn) {
    btn.closest('.address').remove();
}

function addEmailField(add) {
    emailHTML = `<div class="flex singleEmail" style="column-gap: 2%;">
    <div style="width: 50%;">
        <input type="email" name="email">
    </div>
    <div style="width: 2%;">
        <i class="fa-solid fa-trash-can def-color" onclick="removeEmailField(this)"></i>
    </div>
    </div>`
    // document.getElementById("multiEmail").innerHTML += emailHTML;
    add.closest('.emailSection').querySelector('.multiEmail').innerHTML += emailHTML;

    x = add.closest('.emailSection');
    console.log(add.closest('.emailSection').querySelector('.multiEmail'));
}

function removeEmailField(btn) {
    btn.closest('.singleEmail').remove();
}

const form = document.getElementById("detailsForm");
const dob = form.elements['dob']
const age = form.elements['age']

dob.addEventListener('change', (e) => {
    function getAge(date) {
        const dob = new Date(date);
        now = new Date();
        cYear = now.getFullYear();
        cMonth = now.getMonth();
        cDay = now.getDate();
        bYear = dob.getFullYear();
        bMonth = dob.getMonth();
        bDay = dob.getDate();
        dYear = cYear - bYear;
        dMonth = cMonth - bMonth;
        dDay = cDay - bDay;
        return { dYear, dMonth, dDay };
    }
    _age = getAge(dob.value);
    age.value = _age.dYear + " Y, " + _age.dMonth + " M, " + _age.dDay + " D"
})

form.addEventListener('submit', (event) => {
    event.preventDefault()
    const formData = new FormData(form);
    cbs = document.querySelectorAll('input[type=checkbox]')
    cbs.forEach(cb => {
        formData.append(cb.name, cb.checked);
    });
    const entries = formData.entries();
    const details = Object.fromEntries(entries);

    const phoneNumber = form.elements['phoneNumber']
    const sex = form.elements['sex']

    if (_age.dYear < 18 && phoneNumber.value == "") {
        if (sex.value == "Male") {
            ageWiseText = "he"
        } else if (sex.value == "Female") {
            ageWiseText = "she"
        } else {
            ageWiseText = "he/she"
        }
        alert("Please add a contact for the patient as " + ageWiseText + " is minor")
    } else {
        console.log(details);
        // console.log(data);
    }


    // active = form.elements['active']['checked'];
    // prefix = form.elements['prefix']['value'];
    // fname = form.elements['fname']['value'];
    // mname = form.elements['mname']['value'];
    // lname = form.elements['lname']['value'];
    // lname2 = form.elements['lname2']['value'];
    // suffix = form.elements['suffix']['value'];
    // aka = form.elements['aka']['value'];
    // sex = form.elements['sex']['value'];
    // dob = form.elements['dob']['value'];
    // age = form.elements['age']['value'];
    // age = getAge(dob);
    // prefLang = form.elements['prefLang']['value'];
    // interpreter = form.elements['interpreter']['checked'];
    // appointmentStatus = form.elements['appointmentStatus']['value'];
    // risk = form.elements['risk']['value'];
    // maritalStatus = form.elements['maritalStatus']['value'];
    // ssn = form.elements['ssn']['value'];
    // race = form.elements['race']['value'];
    // ethnicity = form.elements['ethnicity']['value'];
    // selfPay = form.elements['selfPay']['checked'];
    // defaultFacility = form.elements['defaultFacility']['value'];
    // defaultProvider = form.elements['defaultProvider']['value'];
    // timezone = form.elements['timezone']['value'];
    // defaultPharmacy = form.elements['defaultPharmacy']['value'];
    // useCurrentPharmacy = form.elements['useCurrentPharmacy']['checked'];
    // samePCP = form.elements['samePCP']['checked'];
    // pcp = form.elements['pcp']['value'];
    // feeSchedule = form.elements['feeSchedule']['value'];
    // addressType = form.elements['addressType']['value'];
    // street = form.elements['street']['value'];
    // zip = form.elements['zip']['value'];
    // city = form.elements['city']['value'];
    // state = form.elements['state']['value'];
    // country = form.elements['country']['value'];
    // phonetype = form.elements['phonetype']['value'];
    // countrtycode = form.elements['countrtycode']['value'];
    // phoneNumber = form.elements['phoneNumber']['value'];
    // faxcode = form.elements['faxcode']['value'];
    // faxnumber = form.elements['faxnumber']['value'];
    // email = form.elements['email']['value'];
    // website = form.elements['website']['value'];

    // address = {
    //     addressType: addressType,
    //     street: street,
    //     zip: zip,
    //     city: city,
    //     state: state,
    //     country: country,
    //     phonetype: phonetype,
    //     countrtycode: countrtycode,
    //     phoneNumber: phoneNumber,
    //     faxcode: faxcode,
    //     faxnumber: faxnumber,
    //     email: email,
    //     website: website,
    // }

    // details = {
    //     active: active,
    //     prefix: prefix,
    //     fname: fname,
    //     mname: mname,
    //     lname: lname,
    //     lname2: lname2,
    //     suffix: suffix,
    //     aka: aka,
    //     dob: dob,
    //     sex: sex,
    //     timezone: timezone,
    //     age: age,
    //     prefLang: prefLang,
    //     interpreter: interpreter,
    //     appointmentStatus: appointmentStatus,
    //     risk: risk,
    //     maritalStatus: maritalStatus,
    //     ssn: ssn,
    //     race: race,
    //     ethnicity: ethnicity,
    //     selfPay: selfPay,
    //     defaultFacility: defaultFacility,
    //     defaultProvider: defaultProvider,
    //     timezone: timezone,
    //     defaultPharmacy: defaultPharmacy,
    //     useCurrentPharmacy: useCurrentPharmacy,
    //     samePCP: samePCP,
    //     pcp: pcp,
    //     feeSchedule: feeSchedule,
    //     addresses: [address],
    // }


    // }
})
