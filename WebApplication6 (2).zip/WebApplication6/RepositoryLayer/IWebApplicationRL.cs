﻿using WebApplication6.Models;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication6.RepositoryLayer
{
    public interface IWebApplicationRL
    {
        public Task<JsonResult> Get(int id);
       
        public Task<JsonResult> Post(Patient pd);
        public Task<JsonResult> Put(int id, Patient pd);
        public Task<JsonResult> Delete(int id);
    }
}

/*
 *  public Task<JsonResult> Get(int id, int pagenumber, int pagesize, int sex_type_id, string fname, string lname, string dob, string orderby);
 */