﻿using Microsoft.AspNetCore.Mvc;
using WebApplication4.Models;

namespace WebApplication4.RepositoryLayer
{
    public interface IWebApplicationnRL
    {
        public Task<JsonResult> Get(int id);
        public Task<JsonResult> Get(int id, int pagenumber, int pagesize, int sex_type_id, string fname, string lname, string dob, string orderby);
        public Task<JsonResult> Post(Patient pd);
        public Task<JsonResult> Put(int id, Patient pd);
        public Task<JsonResult> Delete(int id);
    }
}
