﻿using WebApplication6.RepositoryLayer;
using WebApplication6.Models;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication6.ServiceLayer
{
    public class WebApplicationSL : IWebApplicationSL
    {
        public readonly IWebApplicationRL _webApplicationRL;
        public WebApplicationSL(IWebApplicationRL webApplicationRL)
        {
            _webApplicationRL = webApplicationRL;
        }

        public async Task<dynamic> Get(int id)
        {
            return await _webApplicationRL.Get(id);
        }

        public async Task<int> Post(Patient pd)
        {
            return await _webApplicationRL.Post(pd);
        }

        public async Task<int> Put(int id, Patient pd)
        {
            return await _webApplicationRL.Put(id, pd);
        }
        public async Task<JsonResult> Delete(int id)
        {
            return await _webApplicationRL.Delete(id);
        }
        public async Task<JsonResult> Get(RequestPatientData rpd)
        {
            return await _webApplicationRL.Get(rpd);
        }
    }
}


   
