﻿namespace Assignment.Models
{
    public class PatientDemographics
    {
        public int Patient_id { get; }
        public string? First_Name{ get; set; }
        public string? Middle_Name { get; set; }
        public string? Last_Name { get; set; }
        public DateTime DOB { get; set; }
        public int Sex_Id { get; set; }
        public string CHART_NUMBER { get; }
        private bool is_deleted;
        private DateTime? CreatedOn;
        private DateTime? ModifiedOn;
    }
}
