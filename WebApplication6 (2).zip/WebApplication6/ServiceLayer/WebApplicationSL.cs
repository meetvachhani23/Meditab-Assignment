﻿using WebApplication6.RepositoryLayer;
using WebApplication6.Models;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication6.ServiceLayer
{
    public class WebApplicationSL : IWebApplicationSL
    {
        public readonly IWebApplicationRL _webApplicationRL;
        public WebApplicationSL(IWebApplicationRL webApplicationRL)
        {
            _webApplicationRL = webApplicationRL;
        }

        public async Task<JsonResult> Get(int id)
        {
            return await _webApplicationRL.Get(id);
        }

        public async Task<JsonResult> Post(Patient pd)
        {
            return await _webApplicationRL.Post(pd);
        }

        public async Task<JsonResult> Put(int id, Patient pd)
        {
            return await _webApplicationRL.Put(id, pd);
        }
        public async Task<JsonResult> Delete(int id)
        {
            return await _webApplicationRL.Delete(id);
        }
    }
}

/*
 *  public async Task<JsonResult> Get(int id, int pagenumber, int pagesize, int sex_type_id, string fname, string lname, string dob, string orderby)
        {
            return await _webApplicationRL.Get(id, pagenumber, pagesize, sex_type_id, fname, lname, dob, orderby);
        }
*/