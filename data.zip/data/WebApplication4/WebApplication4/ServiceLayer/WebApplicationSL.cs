﻿
using WebApplication4.Models;
using Microsoft.AspNetCore.Mvc;
using WebApplication4.RepositoryLayer;
namespace WebApplication4.ServicesLayer
{
    public class WebApplicationSL : IWebApplicationSL
    {
        public readonly IWebApplicationRL _IWebApplicationRL;
        public WebApplicationSL(IWebApplicationRL IWebApplicationRL)
        {
            _IWebApplicationRL = IWebApplicationRL;
        }

        public async Task<JsonResult> Get(int id)
        {
            return await _IWebApplicationRL.Get(id);
        }

        public async Task<JsonResult> Get(int id, int pagenumber, int pagesize, int sex_type_id, string fname, string lname, string dob, string orderby)
        {
            return await _IWebApplicationRL.Get(id, pagenumber, pagesize, sex_type_id, fname, lname, dob, orderby);
        }

        public async Task<JsonResult> Post(Patient pd)
        {
            return await _IWebApplicationRL.Post(pd);
        }

        public async Task<JsonResult> Put(int id, Patient pd)
        {
            return await _IWebApplicationRL.Put(id, pd);
        }
        public async Task<JsonResult> Delete(int id)
        {
            return await _IWebApplicationRL.Delete(id);
        }
    }
}
