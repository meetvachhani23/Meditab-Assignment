
--Get patient info using id
create or replace function patientget(patient_id int)
returns table(fname varchar, mname varchar, lname varchar, dob date, chart_no varchar, sex_type_value varchar) as
$$
declare
begin	
	return query select pt.FIRST_NAME, pt.MIDDLE_NAME, pt.LAST_NAME, pt.DOB, pt.CHART_NUMBER, st.SEX_TYPE
	from Patient pt
	left join Sex st on st.SEX_ID=pt.SEX where is_deleted=false and pt.patient_id=$1;
end;
$$ language plpgsql;

select * from patientget(2);


--Insert
create or replace function patientcreate(fname varchar(30), mname varchar(30), lname varchar(30), dob date, sex_type_id int)
returns integer as
$$
declare
	pid integer;
begin
	insert into Patient (FIRST_NAME, MIDDLE_NAME, LAST_NAME, DOB, SEX) values ($1, $2, $3, $4, $5) returning PATIENT_ID into pid;
	return pid;
end;
$$ language plpgsql;

select * from patientcreate(fname=>'RAJU',mname=>'',lname=>'PATel',dob=>'2022-12-10',sex_type_id=>1);
select * from patient;




--update
create or replace function patientupdate(patients_id int, fname varchar(30), mname varchar(30), lname varchar(30), dob date, sex_type_id int)
returns void as
$$
declare
begin
	update Patient set FIRST_NAME=$2, MIDDLE_NAME=$3, LAST_NAME=$4, DOB=$5, SEX=$6 where is_deleted=false and PATIENT_ID=$1;
end;
$$ language plpgsql;


select * from patientupdate(patients_id=>6,fname=>'Meeet',mname=>'',lname=>'Vachhani',dob=>'2023-01-11',sex_type_id=>1);
select * from patient;


--delete
create or replace function patientdelete(patients_id int)
returns void as
$$
declare
begin
	update Patient set is_deleted=true where PATIENT_ID=$1;
end;
$$ language plpgsql;

select * from patientdelete(16);
select * from patient;

--Fetch all record
--create or replace function get_patient_info(patient_id int default null, fname varchar(30) default null, lname varchar(30) default null, dob date default null, sex_type_id int default null,
--pagenumber int default 1, pagesize int default 10, orderby varchar(30) default 'FIRST_NAME')
--returns table(firstname varchar, middlename varchar, lastname varchar, ddob date, cchart_no varchar, ssex_type_value varchar) as
--$$
--declare
--	query_start text := 'select pt.FIRST_NAME, pt.MIDDLE_NAME, pt.LAST_NAME, pt.DOB, pt.CHART_NUMBER, st.SEX_TYPE
--	from Patient pt
--	left join Sex st on st.SEX_ID=pt.SEX ';
--	where_cond text := 'where is_deleted=false';
--	query_end text := ' order by '||$8||' limit $7 offset (($6 - 1) * $7)';
--begin
--	where_cond := where_cond|| case when $1 is not null then ' and pt.PATIENT_ID=$1' else '' end
--							|| case when $2 is not null then ' and pt.FIRST_NAME=$2' else '' end
--							|| case when $3 is not null then ' and pt.LAST_NAME=$3' else '' end
--							|| case when $4 is not null then ' and pt.DOB=$4' else '' end
--							|| case when $5 is not null then ' and pt.SEX=$5' else '' end;
--	return query execute query_start || where_cond || query_end using $1, $2, $3, $4, $5, $6, $7, $8;
--		
--end;
--$$ language plpgsql;
--
--select * from get_patient_info();
--
--
