﻿using WebApplication6.RepositoryLayer;
using WebApplication6.Models;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication6.ServiceLayer
{
    public class WebApplicationSL : IWebApplicationSL
    {
        public readonly IWebApplicationRL _webApplicationRL;
        public WebApplicationSL(IWebApplicationRL webApplicationRL)
        {
            _webApplicationRL = webApplicationRL;
        }

        //Fetch patient detail using id
        public async Task<dynamic> Get(int id)
        {
            return await _webApplicationRL.Get(id);
        }

        //Insert patient record
        public async Task<int> Post(Patient pt)
        {
            return await _webApplicationRL.Post(pt);
        }

        // Update patient record using id
        public async Task<int> Put(int id, Patient pt)
        {
            return await _webApplicationRL.Put(id, pt);
        }
        // Delete patient record using id
        public async Task<JsonResult> Delete(int id)
        {
            return await _webApplicationRL.Delete(id);
        }

        // Get all Patient data in pagination
        public async Task<JsonResult> Get(RequestPatientData rpd)
        {
            return await _webApplicationRL.Get(rpd);
        }
    }
}


   
